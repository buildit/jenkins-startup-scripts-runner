
if (config) {
    def descriptor = instance.getDescriptor("com.datapipe.jenkins.vault.VaultBuildWrapper")
    descriptor.setVaultUrl(config.url)
    descriptor.setAuthToken(config.token)
    descriptor.save()
}
