import jenkins.model.*
import com.cloudbees.plugins.credentials.*
import com.cloudbees.plugins.credentials.common.*
import com.cloudbees.plugins.credentials.domains.*
import com.cloudbees.plugins.credentials.impl.*
import com.cloudbees.jenkins.plugins.sshcredentials.impl.*
import hudson.plugins.sshslaves.*;

def domain = Domain.global()
def store = instance.getExtensionList('com.cloudbees.plugins.credentials.SystemCredentialsProvider')[0].getStore()

removeAllCredentials(store, domain)

config.each { key, credentials ->
    println("Adding ${key} to global credentials")
    def user = user(credentials, key)
    store.addCredentials(domain, user)
}

private removeAllCredentials(store, domain) {
    store.getCredentials(domain).each {
        println("Removing ${it.id} from global credentials")
        store.removeCredentials(domain, it)
    }
}

private user(credentials, key) {
    switch (credentials.type) {
        case 'SSH':
            return new BasicSSHUserPrivateKey(CredentialsScope.GLOBAL, key, credentials.username,
                    new BasicSSHUserPrivateKey.FileOnMasterPrivateKeySource(credentials.privateKeyFile),
                    credentials.password, credentials.description)
        case 'HashicorpVault':
            def constructor = Class.forName("digital.buildit.jenkins.credentials.vault.HashicorpVaultCredentialsImpl").getConstructor(CredentialsScope.class, String.class, String.class, String.class, String.class, String.class)
            return constructor.newInstance(CredentialsScope.GLOBAL, key, credentials.key, credentials.passwordKey, credentials.usernameKey, credentials.description)
        default:
            return new UsernamePasswordCredentialsImpl(CredentialsScope.GLOBAL, key, credentials.description, credentials.username, credentials.password)
    }
}
