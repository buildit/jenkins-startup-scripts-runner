import hudson.model.Node
import hudson.plugins.sshslaves.SSHLauncher
import hudson.slaves.ComputerLauncher
import hudson.slaves.DumbSlave
import hudson.slaves.EnvironmentVariablesNodeProperty
import hudson.slaves.EnvironmentVariablesNodeProperty.Entry
import hudson.slaves.JNLPLauncher
import hudson.slaves.RetentionStrategy

removeAllNodes(instance)

config?.each{ key, node ->
    println("Adding node ${key}")

    def env = node?.env?.collect { k, v -> new Entry(k, v) }
    def slave = new DumbSlave(
            node.name as String, node.description as String, node.remoteFS as String,
            node.numExecutors as String, mode(node.mode), node.label as String,
            launcher(node.launchType, node.host, node.jnlpTunnel, node.jnlpVmArgs, node.credentialsId),
            RetentionStrategy.INSTANCE)
    slave.getNodeProperties().add(new EnvironmentVariablesNodeProperty(env))
    instance.addNode(slave)
}

instance.save()

private def removeAllNodes(instance) {
    instance.getNodes().each{ node ->
        println("Removing node with name ${node.name}")
        instance.removeNode(node)
    }
}

private Node.Mode mode(mode) {
    switch (mode) {
        case 'EXCLUSIVE':
            return Node.Mode.EXCLUSIVE
        case 'NORMAL':
            return Node.Mode.NORMAL
        default:
            return Node.Mode.NORMAL
    }
}

private ComputerLauncher launcher(launchType, host, jnlpTunnel, jnlpVmArgs, credentialsId) {
    switch (launchType) {
        case 'SSH':
            return new SSHLauncher(host, 22, credentialsId, '', '', '', '', null, 0, 0)
        case 'JNLP':
            return new JNLPLauncher(jnlpTunnel, jnlpVmArgs)
        default:
            return new JNLPLauncher(jnlpTunnel, jnlpVmArgs)
    }
}
