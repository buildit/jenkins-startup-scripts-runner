config.each {
    createDirectories(it.value.path)
    File file = new File(it.value.path)
    file.createNewFile()
    file.text = it.value.contents.trim()
    execute("chmod ${it.value.mode} ${it.value.path}")
}

private createDirectories(path){
    if(path.indexOf("/") != -1){
        def directoryPath = path.substring(0, path.lastIndexOf('/'))
        File directory = new File(directoryPath)
        directory.mkdirs()
    }
}

private execute(String command) {
    return execute(command, new File(System.properties.'user.dir'))
}

private execute(String command, File workingDir) {
    println("executing command: ${command}")
    def process = new ProcessBuilder(addShellPrefix(command))
            .directory(workingDir)
            .redirectErrorStream(true)
            .start()
    process.inputStream.eachLine {println it}
    process.waitFor();
    println("exit value: ${process.exitValue()}")
    if(process.exitValue() > 0){
        throw new RuntimeException("Process exited with non-zero value: ${process.exitValue()}")
    }
}

private addShellPrefix(String command) {
    commandArray = new String[3]
    commandArray[0] = "sh"
    commandArray[1] = "-c"
    commandArray[2] = command
    return commandArray
}