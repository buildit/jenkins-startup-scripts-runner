import jenkins.model.*
import javaposse.jobdsl.plugin.*
import hudson.plugins.git.*

import javax.xml.transform.stream.StreamSource
import java.util.Collections
import java.util.List
import hudson.triggers.TimerTrigger
import groovy.text.*

config.each { jobName, values ->
    def bindings = [:]
    bindings << values
    bindings.credentialsBlock = bindings.credentialsId ? "<credentialsId>${bindings.credentialsId}</credentialsId>" : ''
    def xml = getXmlFromTemplate(bindings)
    def stream = new ByteArrayInputStream(xml.bytes)
    def project = Jenkins.getInstance().getItem(jobName)
    if (project) {
        println("Updating job with name ${jobName}")
        project.updateByXml(new StreamSource(stream))
        project.save()
    } else {
        println("Creating job with name ${jobName}")
        project = Jenkins.getInstance().createProjectFromXML(jobName, stream)
    }
    def causeAction = new hudson.model.CauseAction(new TimerTrigger.TimerTriggerCause())
    instance.getQueue().schedule(project, 10, causeAction)

}

String getXmlFromTemplate(bindings) {
    def xml = '''
    <?xml version='1.0' encoding='UTF-8'?>
    <project>
        <actions/>
        <description></description>
        <keepDependencies>false</keepDependencies>
        <scm class="hudson.plugins.git.GitSCM" plugin="git@3.0.0">
            <configVersion>2</configVersion>
            <userRemoteConfigs>
                <hudson.plugins.git.UserRemoteConfig>
                    <url>${url}</url>
                    ${credentialsBlock}
                </hudson.plugins.git.UserRemoteConfig>
            </userRemoteConfigs>
            <branches>
                <hudson.plugins.git.BranchSpec>
                    <name>${branch}</name>
                </hudson.plugins.git.BranchSpec>
            </branches>
            <doGenerateSubmoduleConfigurations>false</doGenerateSubmoduleConfigurations>
            <submoduleCfg class="list"/>
            <extensions/>
        </scm>
        <canRoam>true</canRoam>
        <disabled>false</disabled>
        <blockBuildWhenDownstreamBuilding>false</blockBuildWhenDownstreamBuilding>
        <blockBuildWhenUpstreamBuilding>false</blockBuildWhenUpstreamBuilding>
        <triggers>
            <hudson.triggers.SCMTrigger>
                <spec>H/5 * * * *</spec>
                <ignorePostCommitHooks>false</ignorePostCommitHooks>
            </hudson.triggers.SCMTrigger>
        </triggers>
        <concurrentBuild>false</concurrentBuild>
        <builders>
            <javaposse.jobdsl.plugin.ExecuteDslScripts plugin="job-dsl@1.51">
                <targets>${targets}</targets>
                <usingScriptText>false</usingScriptText>
                <ignoreExisting>false</ignoreExisting>
                <removedJobAction>DELETE</removedJobAction>
                <removedViewAction>DELETE</removedViewAction>
                <lookupStrategy>JENKINS_ROOT</lookupStrategy>
                <additionalClasspath></additionalClasspath>
            </javaposse.jobdsl.plugin.ExecuteDslScripts>
        </builders>
        <publishers/>
        <buildWrappers/>
    </project>
    '''
    def engine = new groovy.text.SimpleTemplateEngine()
    def template = engine.createTemplate(xml).make(bindings)
    return template.toString().trim()
}