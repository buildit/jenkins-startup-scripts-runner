import org.apache.ivy.Ivy
import org.apache.ivy.core.module.descriptor.DefaultDependencyArtifactDescriptor
import org.apache.ivy.core.module.descriptor.DefaultDependencyDescriptor
import org.apache.ivy.core.module.descriptor.DefaultModuleDescriptor
import org.apache.ivy.core.module.id.ModuleRevisionId
import org.apache.ivy.core.report.ResolveReport
import org.apache.ivy.core.resolve.ResolveOptions
import org.apache.ivy.core.settings.IvySettings
import org.apache.ivy.plugins.parser.xml.XmlModuleDescriptorWriter
import org.apache.ivy.plugins.resolver.URLResolver

import java.security.MessageDigest
import java.security.DigestInputStream

DEFAULT_ARTIFACT_PATTERN = "http://updates.jenkins-ci.org/download/plugins/[module]/[revision]/[module].[ext]"
PLUGIN_EXT = "hpi"
PLUGIN_CACHE = "plugins-cache"

def artifactPattern = config.artifactPattern ?: DEFAULT_ARTIFACT_PATTERN

def log = new File("${jenkinsHome}/plugins/plugins.log")
def latestLog = new File("${jenkinsHome}/plugins/plugins-latest.log")

def hash = hashString(config.pluginArtifacts.toString())

if(log.exists() && log.text == hash && !pullsLatest(config.pluginArtifacts)){
    println("No changes to list of plugins and 'latest' use not detected. Nothing to do.")
    return
}

println("Changes or 'latest' version use detected. Beginning plugin resolution.")

def pluginsCache = resolvePlugins(artifactPattern, config.pluginArtifacts)

def latestHash = hashLatestPlugins(pluginsCache)

if(log.exists() && log.text == hash && latestLog.exists() && latestLog.text == latestHash){
    println("No changes to 'latest' plugins detected. Nothing to do.")
    return
}

println("Wiping plugin directory")

new AntBuilder().delete(dir:"${jenkinsHome}/plugins",failonerror:true)

pluginsCache.each {
    new AntBuilder().copy(file: "${it.absolutePath}", tofile: "${jenkinsHome}/plugins/${it.name}")
    clearPluginsMarkedAsLatestFromCache(it)
}

println("Logging new plugin state")
log.text = hash
latestLog.text = latestHash

println("Initiating restart")
instance.restart()

String hashString(String string) {
    MessageDigest digest = MessageDigest.getInstance('MD5')
    byte[] arrayBytes = digest.digest(string.getBytes("UTF-8"))
    StringBuffer stringBuffer = new StringBuffer()
    for (int i = 0; i < arrayBytes.length; i++) {
        stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16).substring(1))
    }
    return stringBuffer.toString()
}

def hashLatestPlugins(list) {
    StringBuffer buf = new StringBuffer()
    list.each {
        if(isLatest(it)){
           buf.append(hashFile(it))
        }
    }
    return buf.toString()
}

def hashFile(File file) {
    file.withInputStream {
        new DigestInputStream(it, MessageDigest.getInstance('MD5')).withStream {
            it.eachByte {}
            it.messageDigest.digest().encodeHex() as String
        }
    }
}

def pullsLatest(list){
    list.toString().contains(":latest")
}

def clearPluginsMarkedAsLatestFromCache(File plugin){
    if(isLatest(plugin)){
        plugin.delete()
    }
}

def isLatest(File plugin){
    return plugin.name.endsWith("-latest.${PLUGIN_EXT}")
}

def resolvePlugins(pattern, plugins) {

    IvySettings ivySettings = new IvySettings()
    ivySettings.setDefaultCache(new File("${jenkinsHome}/${PLUGIN_CACHE}"))
    URLResolver resolver = new URLResolver()
    resolver.setM2compatible(true)
    resolver.setName('central')
    resolver.setCheckmodified(true)
    resolver.setChangingMatcher("regexp")
    resolver.addArtifactPattern(pattern)
    ivySettings.addResolver(resolver)
    ivySettings.setDefaultResolver(resolver.getName())
    Ivy ivy = Ivy.newInstance(ivySettings)

    File ivyfile = File.createTempFile('ivy', '.xml')
    ivyfile.deleteOnExit()

    DefaultModuleDescriptor md = DefaultModuleDescriptor.newDefaultInstance(ModuleRevisionId.newInstance('', '', ''))

    plugins.each {
        def bits = it.toString().split(":")
        if(bits.length != 2){
            throw new IllegalArgumentException("Error parsing plugin pluginArtifact: ${it.toString()}")
        }
        def artifactId = bits[0]
        def version = bits[1]

        DefaultDependencyDescriptor dd = new DefaultDependencyDescriptor(md, ModuleRevisionId.newInstance('', artifactId, version, [changing:'true']), false, false, true)
        DefaultDependencyArtifactDescriptor dad = new DefaultDependencyArtifactDescriptor(dd, artifactId, PLUGIN_EXT, PLUGIN_EXT, null, [:])
        dd.addDependencyArtifact('default', dad)
        md.addDependency(dd)
    }
    XmlModuleDescriptorWriter.write(md, ivyfile)

    String[] confs = ['default']
    ResolveOptions resolveOptions = new ResolveOptions().setConfs(confs)

    ResolveReport report = ivy.resolve(ivyfile.toURL(), resolveOptions)

    def results = []
    report.getAllArtifactsReports().each {
        results.add(it.getLocalFile())
    }

    return results
}

